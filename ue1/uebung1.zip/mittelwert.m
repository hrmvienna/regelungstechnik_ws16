function out = mittelwert(a,b)

% Hier steht die Information zur function
% out = mittelwert(a,b) berechnet den Mittelwert der Zahlen a und b

out = (a+b)/2;


end